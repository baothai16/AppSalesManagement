﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPageUser.Master" AutoEventWireup="true" CodeBehind="pageDANGKY.aspx.cs" Inherits="QUANLYBANHANG_ONLINE_NBT.pageDANGKY" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="center_title_bar">Đăng ký tài khoản</div>
    <table style="width: 100%;">
        <tr>
            <td class="auto-style2" style="width:180px;">Tên đăng nhập</td>
            <td><asp:TextBox ID="txtTENDANGNHAP" runat="server"></asp:TextBox>
                <asp:RequiredFieldValidator ID="rfvTDN" runat="server" ControlToValidate="txtTENDANGNHAP" ErrorMessage="Bắt buộc nhập" ForeColor="Red" />
            </td>
        </tr>
        <tr>
            <td class="auto-style2">Mật khẩu</td>
            <td><asp:TextBox ID="txtMATKHAU" runat="server" TextMode="Password"></asp:TextBox>
                <asp:RequiredFieldValidator ID="rfvMK" runat="server" ControlToValidate="txtMATKHAU" ErrorMessage="Bắt buộc nhập" ForeColor="Red" />
            </td>
        </tr>
        <tr>
            <td class="auto-style2">Nhập lại mật khẩu</td>
            <td><asp:TextBox ID="txtNHAPLAIMATKHAU" runat="server" TextMode="Password"></asp:TextBox>
                <asp:CompareValidator ID="cvMK" runat="server" ControlToValidate="txtNHAPLAIMATKHAU" ControlToCompare="txtMATKHAU" ErrorMessage="Mật khẩu không khớp" ForeColor="Red" />
            </td>
        </tr>
        <tr>
            <td class="auto-style2">Họ tên</td>
            <td><asp:TextBox ID="txtHOTEN" runat="server"></asp:TextBox></td>
        </tr>
        <tr>
            <td class="auto-style2">Email</td>
            <td><asp:TextBox ID="txtEMAIL" runat="server"></asp:TextBox></td>
        </tr>
        <tr>
            <td class="auto-style2">Điện thoại</td>
            <td><asp:TextBox ID="txtDIENTHOAI" runat="server"></asp:TextBox></td>
        </tr>
        <tr>
            <td class="auto-style2">Địa chỉ</td>
            <td><asp:TextBox ID="txtDIACHI" runat="server"></asp:TextBox></td>
        </tr>
        <tr>
            <td class="auto-style1" colspan="2">
                <asp:Button ID="btnDangKy" runat="server" Text="Đăng Ký" OnClick="btnDangKy_Click"/>
                <asp:Label ID="lblThongBao" runat="server" Font-Bold="true"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2">Đã có tài khoản? <a href="pageLOGIN.aspx">Đăng nhập</a></td>
        </tr>
    </table>
</asp:Content>
